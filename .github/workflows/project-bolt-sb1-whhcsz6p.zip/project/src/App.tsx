import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { SquadView } from './components/squad/SquadView';

function App() {
  const [activeSection, setActiveSection] = useState('squad');

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Navigation 
        activeSection={activeSection}
        onNavigate={setActiveSection}
      />
      <main className="flex-1 overflow-auto">
        {activeSection === 'squad' ? (
          <SquadView />
        ) : (
          <Dashboard />
        )}
      </main>
    </div>
  );
}

export default App;