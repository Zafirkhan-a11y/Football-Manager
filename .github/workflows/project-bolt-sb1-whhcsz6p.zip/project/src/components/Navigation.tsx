import React from 'react';
import { 
  Users, 
  Trophy, 
  Building2, 
  DollarSign, 
  Calendar, 
  ClipboardList,
  Settings
} from 'lucide-react';

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-2 w-full p-3 rounded-lg transition-colors
      ${active 
        ? 'bg-blue-600 text-white' 
        : 'text-gray-700 hover:bg-gray-100'
      }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

interface NavigationProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeSection, onNavigate }) => {
  return (
    <div className="w-64 h-screen bg-white border-r border-gray-200 p-4">
      <div className="flex items-center space-x-2 mb-8">
        <Trophy className="w-8 h-8 text-blue-600" />
        <h1 className="text-xl font-bold">Football Manager</h1>
      </div>
      
      <nav className="space-y-2">
        <NavItem
          icon={<Users className="w-5 h-5" />}
          label="Squad"
          active={activeSection === 'squad'}
          onClick={() => onNavigate('squad')}
        />
        <NavItem
          icon={<ClipboardList className="w-5 h-5" />}
          label="Staff"
          active={activeSection === 'staff'}
          onClick={() => onNavigate('staff')}
        />
        <NavItem
          icon={<Building2 className="w-5 h-5" />}
          label="Club"
          active={activeSection === 'club'}
          onClick={() => onNavigate('club')}
        />
        <NavItem
          icon={<Calendar className="w-5 h-5" />}
          label="Matches"
          active={activeSection === 'matches'}
          onClick={() => onNavigate('matches')}
        />
        <NavItem
          icon={<DollarSign className="w-5 h-5" />}
          label="Finances"
          active={activeSection === 'finances'}
          onClick={() => onNavigate('finances')}
        />
        <NavItem
          icon={<Settings className="w-5 h-5" />}
          label="Settings"
          active={activeSection === 'settings'}
          onClick={() => onNavigate('settings')}
        />
      </nav>
    </div>
  );
};