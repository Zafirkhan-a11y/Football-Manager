import React from 'react';
import { 
  TrendingUp, 
  AlertTriangle, 
  Mail, 
  Calendar,
  Trophy,
  Users
} from 'lucide-react';

interface DashboardCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  trend?: string;
  trendUp?: boolean;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ 
  title, 
  value, 
  icon, 
  trend, 
  trendUp 
}) => (
  <div className="bg-white rounded-xl p-6 shadow-sm">
    <div className="flex justify-between items-start">
      <div>
        <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
        <p className="text-2xl font-bold mt-1">{value}</p>
        {trend && (
          <p className={`text-sm mt-2 ${trendUp ? 'text-green-500' : 'text-red-500'}`}>
            {trend}
          </p>
        )}
      </div>
      <div className="p-3 bg-blue-50 rounded-lg">
        {icon}
      </div>
    </div>
  </div>
);

export const Dashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Dashboard</h2>
        <div className="flex space-x-2">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Next Match
          </button>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">
            Continue
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard
          title="Team Morale"
          value="Good"
          icon={<TrendingUp className="w-6 h-6 text-blue-600" />}
          trend="+5% from last week"
          trendUp={true}
        />
        <DashboardCard
          title="Injured Players"
          value="2"
          icon={<AlertTriangle className="w-6 h-6 text-yellow-500" />}
        />
        <DashboardCard
          title="Transfer Budget"
          value="£50M"
          icon={<Mail className="w-6 h-6 text-green-500" />}
        />
        <DashboardCard
          title="Next Match"
          value="vs Liverpool"
          icon={<Calendar className="w-6 h-6 text-purple-500" />}
        />
        <DashboardCard
          title="League Position"
          value="4th"
          icon={<Trophy className="w-6 h-6 text-orange-500" />}
          trend="Champions League spot"
          trendUp={true}
        />
        <DashboardCard
          title="Squad Size"
          value="25"
          icon={<Users className="w-6 h-6 text-indigo-500" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Recent Results</h3>
          {/* Add match results component here */}
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Upcoming Fixtures</h3>
          {/* Add fixtures component here */}
        </div>
      </div>
    </div>
  );
};