import React, { useState } from 'react';
import { Player } from '../../types';
import { SquadList } from './SquadList';
import { PlayerDetails } from './PlayerDetails';
import { Filter, Search, Users } from 'lucide-react';

// Mock data for demonstration
const mockPlayers: Player[] = [
  {
    id: "p1",
    name: "Marcus Rashford",
    position: "FWD",
    age: 25,
    value: 85000000,
    wage: 200000,
    morale: 85,
    form: 8,
    fitness: 95,
    potential: 88
  },
  {
    id: "p2",
    name: "Bruno Fernandes",
    position: "MID",
    age: 28,
    value: 75000000,
    wage: 240000,
    morale: 90,
    form: 9,
    fitness: 92,
    potential: 89
  },
  {
    id: "p3",
    name: "Lisandro Martínez",
    position: "DEF",
    age: 25,
    value: 50000000,
    wage: 120000,
    morale: 82,
    form: 7,
    fitness: 88,
    potential: 85
  },
  {
    id: "p4",
    name: "André Onana",
    position: "GK",
    age: 27,
    value: 35000000,
    wage: 160000,
    morale: 78,
    form: 6,
    fitness: 96,
    potential: 86
  }
];

export const SquadView: React.FC = () => {
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPlayers = mockPlayers.filter(player =>
    player.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Users className="w-6 h-6 text-blue-600" />
          <h2 className="text-2xl font-bold">Squad Overview</h2>
        </div>
        <div className="flex space-x-3">
          <button className="px-4 py-2 bg-white text-gray-700 rounded-lg hover:bg-gray-50 flex items-center space-x-2 border border-gray-200">
            <Filter className="w-4 h-4" />
            <span>Filter</span>
          </button>
          <div className="relative">
            <input
              type="text"
              placeholder="Search players..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SquadList 
            players={filteredPlayers}
            onPlayerSelect={setSelectedPlayer}
          />
        </div>
        <div>
          {selectedPlayer ? (
            <PlayerDetails 
              player={selectedPlayer}
              onClose={() => setSelectedPlayer(null)}
            />
          ) : (
            <div className="bg-white rounded-xl shadow-sm p-6 text-center">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                Select a player to view their details
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};