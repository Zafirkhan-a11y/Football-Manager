import React from 'react';
import { Player } from '../../types';
import {
  TrendingUp,
  TrendingDown,
  Heart,
  DollarSign,
  Smile,
  Star,
  Activity,
  Award
} from 'lucide-react';

interface PlayerDetailsProps {
  player: Player;
  onClose: () => void;
}

export const PlayerDetails: React.FC<PlayerDetailsProps> = ({ player, onClose }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{player.name}</h2>
          <p className="text-gray-500">{player.position}</p>
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-500"
        >
          ×
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Star className="w-5 h-5 text-yellow-400 mr-2" />
              <span className="text-gray-600">Potential</span>
            </div>
            <span className="font-semibold">{player.potential}/100</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Heart className="w-5 h-5 text-red-500 mr-2" />
              <span className="text-gray-600">Fitness</span>
            </div>
            <span className="font-semibold">{player.fitness}%</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Activity className="w-5 h-5 text-blue-500 mr-2" />
              <span className="text-gray-600">Form</span>
            </div>
            <div className="flex items-center">
              {player.form >= 7 ? (
                <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
              ) : player.form <= 4 ? (
                <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
              ) : (
                <Activity className="w-4 h-4 text-yellow-500 mr-1" />
              )}
              <span className="font-semibold">{player.form}/10</span>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <DollarSign className="w-5 h-5 text-green-500 mr-2" />
              <span className="text-gray-600">Value</span>
            </div>
            <span className="font-semibold">£{formatValue(player.value)}</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Award className="w-5 h-5 text-purple-500 mr-2" />
              <span className="text-gray-600">Wage</span>
            </div>
            <span className="font-semibold">£{formatValue(player.wage)}/week</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Smile className="w-5 h-5 text-yellow-500 mr-2" />
              <span className="text-gray-600">Morale</span>
            </div>
            <span className="font-semibold">{getMoraleText(player.morale)}</span>
          </div>
        </div>
      </div>

      <div className="mt-6 flex space-x-3">
        <button className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
          Training
        </button>
        <button className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
          Contract
        </button>
        <button className="flex-1 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
          Transfer
        </button>
      </div>
    </div>
  );
};

const formatValue = (value: number): string => {
  if (value >= 1000000) {
    return `${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(1)}K`;
  }
  return value.toString();
};

const getMoraleText = (morale: number): string => {
  if (morale >= 90) return 'Excellent';
  if (morale >= 75) return 'Very Good';
  if (morale >= 60) return 'Good';
  if (morale >= 45) return 'Average';
  if (morale >= 30) return 'Poor';
  return 'Very Poor';
};