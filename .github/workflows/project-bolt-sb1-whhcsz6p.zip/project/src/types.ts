export interface Player {
  id: string;
  name: string;
  position: string;
  age: number;
  value: number;
  wage: number;
  morale: number;
  form: number;
  fitness: number;
  potential: number;
}

export interface Staff {
  id: string;
  name: string;
  role: string;
  expertise: number;
  wage: number;
}

export interface Club {
  id: string;
  name: string;
  balance: number;
  reputation: number;
  stadiumCapacity: number;
  trainingFacilities: number;
}

export interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  competition: string;
  score?: string;
}